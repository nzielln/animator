package cs5004.animator.view;

import org.junit.Test;

import static org.junit.Assert.*;

public class ReaderTest {
  
  
  @Test
  public void readIn() {
  }
  
  @Test
  public void getInputs() {
  }
  
  @Test
  public void makeModel() {
  }
  
  @Test
  public void getModel() {
  }
}