package cs5004.animator.view;


/**
 * An interface for a Playback View object.
 */
public interface Playback {
  //ASSIGNMENT 8


}
