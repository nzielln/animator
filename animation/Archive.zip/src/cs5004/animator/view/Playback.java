package cs5004.animator.view;

public interface Playback {


}
