package cs5004.animator.view;

import javax.swing.JFrame;

/**
 * A PlaybackView class that extends JFrame and implements the Playback interface.
 */
public class PlaybackView extends JFrame implements Playback {
  /*private GraphicView view;
  //ASSIGNMENT 8
  
  public PlaybackView(List<Shape> m, int w, int h, int x, int y) {
    super("Animation");
    setSize(w, h);
    setLocation(x, y);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(null);
    
    this.view = new GraphicView();
    setVisible(true);
    add(view);
    view.setVisible(true);
  }
  
   */
}
