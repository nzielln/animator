package cs5004.animator;


import java.io.FileNotFoundException;
import java.util.Scanner;

import cs5004.animator.view.View;
import cs5004.animator.view.ViewFactory;

public class EasyAnimator {
  
  public static void main(String[] args) throws FileNotFoundException {
    ViewFactory factory = new ViewFactory();
    System.out.println("Provide an \"-in\" file, \"-out\" the type of \"-view\" "
            + "you would like to see, and \"-speed\" if applicable.");
    Scanner scan = new Scanner(System.in);
    
    String in = scan.nextLine();
    View view = factory.create(in);
    view.readInputs(in);
    view.getReadable();
   
    view.animate();
   
 
  }
}

//test text: -in smalldemo.txt -view text -speed 2
//test svg: -in smalldemo.txt -view svg -speed 2 -out s.svg
//test visual: -in smalldemo.txt -view visual -speed 20
    

